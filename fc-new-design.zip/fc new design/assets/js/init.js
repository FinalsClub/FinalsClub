$(function() {

    // Remember to minimize JavaScripts before going into production

    function include(file) {

    }

});